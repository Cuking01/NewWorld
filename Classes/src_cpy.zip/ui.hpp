#pragma once

namespace UI
{

#include"ui/fight.hpp"
#include"ui/select_level.hpp"
#include"ui/start.hpp"


};
