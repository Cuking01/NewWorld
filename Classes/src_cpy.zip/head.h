#include<stdio.h>
#include<stdlib.h>
#include<cmath>
#include<new>
#include<set>
#include<vector>
#include<deque>
#include<queue>
#include<map>
#include<string>
#include<concepts>
#include<utility>
#include<functional>
#include<thread>
#include<mutex>
#include<chrono>
#include<random>
#include<fstream>


using namespace std::literals;

#include"type.h"
#include"val.h"
#include"tool.h"
