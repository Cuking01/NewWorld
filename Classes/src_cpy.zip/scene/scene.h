#pragma once

enum class KB_Dir:u2;

struct Scene;

