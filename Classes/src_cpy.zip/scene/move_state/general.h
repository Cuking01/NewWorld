#pragma once

struct General;
