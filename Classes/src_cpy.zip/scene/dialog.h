#pragma once

struct Utterance;
struct Dialog;

