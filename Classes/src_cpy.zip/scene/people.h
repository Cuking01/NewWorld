#pragma once

enum class Dir:u2;
struct People;
