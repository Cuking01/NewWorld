#pragma once

struct Object;

