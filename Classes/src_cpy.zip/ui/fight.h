#pragma once

struct Fight;

