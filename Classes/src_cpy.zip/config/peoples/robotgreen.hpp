#pragma once

void robotgreen_init();

