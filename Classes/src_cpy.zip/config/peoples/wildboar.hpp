#pragma once

void wildboar_init();