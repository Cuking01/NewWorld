#pragma once

void effect_init();
