#pragma once

void robot2_init();

