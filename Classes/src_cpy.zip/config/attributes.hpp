#pragma once

struct Attributes
{
    Attribute HP_lim;
    Attribute ATK,DEF,HARD,SPEED;
    Attribute max_jump_cnt;
};
