#pragma once

struct Attribute;
