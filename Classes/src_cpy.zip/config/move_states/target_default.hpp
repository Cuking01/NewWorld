#pragma once

struct Target_Default_MS: AI_MS
{
	Target_Default_MS(Scene*scene,People*people);
};

void target_default_init();

