#pragma once

struct Chapter10:Progress
{
	int j=0;
	Chapter10(::Scene::Scene*scene);
};

void chapter10_init();