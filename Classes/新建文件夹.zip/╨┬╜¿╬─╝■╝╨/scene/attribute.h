#pragma once

struct Attribute;
struct Attributes;
