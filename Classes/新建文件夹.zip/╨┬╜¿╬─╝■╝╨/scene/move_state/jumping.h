#pragma once

struct Jumping;
