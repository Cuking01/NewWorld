#pragma once

struct Skill;
