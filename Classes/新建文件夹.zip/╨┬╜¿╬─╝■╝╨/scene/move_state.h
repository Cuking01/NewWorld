#pragma once

struct Move_State;

namespace Move_States
{

	#include"move_state/general.h"
	#include"move_state/freeze.h"
	#include"move_state/jumping.h"
	#include"move_state/death.h"
};

