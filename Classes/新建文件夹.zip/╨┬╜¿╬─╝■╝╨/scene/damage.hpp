#pragma once

struct Damage
{
	f3 x;
	Damage(f3 x);
};

