#pragma once

struct Weapon;


