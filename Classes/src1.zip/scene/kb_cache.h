#pragma once

struct KB_Cache;
