#pragma once

template<typename T>
struct Trigger;
