#pragma once

namespace UI
{

#include"ui/fight.cpp"
#include"ui/select_level.cpp"
#include"ui/help.cpp"
#include"ui/start.cpp"


};
