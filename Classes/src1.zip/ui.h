#pragma once

namespace UI
{

#include"ui/fight.h"
#include"ui/select_level.h"
#include"ui/help.h"
#include"ui/start.h"


};
