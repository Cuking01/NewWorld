#pragma once

struct Clipping_Rectangle;


