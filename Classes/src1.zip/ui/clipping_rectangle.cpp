#pragma once


Clipping_Rectangle::create(s2 w,s2 h)
{
	auto*p=new Clipping_Rectangle;
	auto*rectangle=DrawNode::create();
	rectangle->drawSolidRect(Vec2(0,0),Vec2(w,h),)
}
