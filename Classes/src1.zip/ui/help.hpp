#pragma once

struct Help: cocos2d::Scene
{
	
	virtual bool init();
	
	CREATE_FUNC(Help);
};

